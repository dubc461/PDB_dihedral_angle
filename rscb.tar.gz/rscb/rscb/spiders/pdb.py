# -*- coding: utf-8 -*-
import scrapy
import re
import os

class PdbSpider(scrapy.Spider):
    name = "pdb"
    allowed_domains = ["www.rcsb.org"]
    start_urls = []

#ADD
    url_base = "http://www.rcsb.org/pdb/explore/explore.do?structureId="
    data_file = open('pdb_entry_type.txt')
    data_table = data_file.readlines()
    data_file.close()

    for line in data_table:
      start_urls.append(url_base + line.split()[0])
    del data_table[:]
#ADD_END

    def parse(self, response):
      #ADD
      del_htmltag = re.compile(r'<.*?>')
      list_method = response.xpath('//div[@class = "col-md-5 col-sm-4 col-xs-12"]//ul[@class = "list-unstyled"]/li').extract()
      method = list_method[0].replace('\n', '').replace('  ','').split('\n')
      method = del_htmltag.sub('', str(method)).split(':')[1][:-2]
      #ID TYPE
      pdb_id = response.url[-4:]#.upper()
      os_cmd = "grep " + "\"" + pdb_id + "\"" + " pdb_entry_type.txt | gawk '{print $2}'"
      pdb_type = os.popen(os_cmd).read().strip()
      os_cmd = "grep " + "\"" + pdb_id + "\"" + " pdb_entry_type.txt | gawk '{print $3}'"
      pdb_method = os.popen(os_cmd).read().strip()
      #ADD_END

      list_target = response.xpath('//ul[@class = "list-unstyled experimentaldata col-md-12 col-sm-6"]/li')
      items = []
      items.append(pdb_id)
      for line in list_target.extract():
        word = del_htmltag.sub('', line).replace('\n', '').replace('  ','')
        items.append(word)

      file_name = "%s_%s.dat" % (pdb_type, pdb_method)
      print file_name

      with open(file_name, 'a+') as files:
        for write_word in items:
          files.write(write_word.encode('utf-8'))
          if write_word != items[-1]:
            files.write(", ")
          else:
            files.write(" \n") 
      pass
